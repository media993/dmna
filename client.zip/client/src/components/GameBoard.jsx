import React, { useState, useEffect } from 'react';
import DominoTile from './DominoTile';

const GameBoard = ({ 
  board, 
  onPlaceDomino, 
  selectedDomino, 
  isCurrentPlayer,
  gameStarted 
}) => {
  const [hoveredPosition, setHoveredPosition] = useState(null);
  const [boardLayout, setBoardLayout] = useState([]);

  useEffect(() => {
    if (board && board.length > 0) {
      // Calculate board layout for better visual representation
      const layout = board.map((domino, index) => ({
        ...domino,
        index,
        isHorizontal: index % 2 === 0, // Alternate orientation for visual appeal
        x: index * 80, // Spacing between dominoes
        y: 0
      }));
      setBoardLayout(layout);
    }
  }, [board]);

  const handlePositionClick = (position) => {
    if (!isCurrentPlayer || !selectedDomino || !gameStarted) return;
    onPlaceDomino(selectedDomino.id, position);
  };

  const canPlaceAtPosition = (position) => {
    if (!selectedDomino || !board || board.length === 0) return false;
    
    const leftEnd = board[0]?.left;
    const rightEnd = board[board.length - 1]?.right;
    
    if (position === 'left') {
      return selectedDomino.left === leftEnd || selectedDomino.right === leftEnd;
    } else {
      return selectedDomino.left === rightEnd || selectedDomino.right === rightEnd;
    }
  };

  if (!gameStarted) {
    return (
      <div className="game-board">
        <div className="text-white text-center">
          <div className="text-6xl mb-4">🎲</div>
          <h2 className="text-2xl font-bold mb-2">لعبة الدومينو</h2>
          <p className="text-lg opacity-75">في انتظار بدء اللعبة...</p>
        </div>
      </div>
    );
  }

  if (!board || board.length === 0) {
    return (
      <div className="game-board">
        <div className="text-white text-center">
          <div className="text-4xl mb-4">🎯</div>
          <h3 className="text-xl font-bold mb-2">ابدأ اللعبة</h3>
          <p className="opacity-75">ضع أول قطعة دومينو على اللوحة</p>
        </div>
      </div>
    );
  }

  return (
    <div className="game-board">
      <div className="flex items-center justify-center min-h-[300px] relative">
        {/* Left placement area */}
        {board.length > 0 && (
          <div
            className={`
              w-16 h-32 border-2 border-dashed border-white/30 rounded-lg
              flex items-center justify-center cursor-pointer
              transition-all duration-200 mr-4
              ${hoveredPosition === 'left' ? 'border-blue-400 bg-blue-400/20' : ''}
              ${canPlaceAtPosition('left') && selectedDomino ? 'border-green-400 hover:bg-green-400/20' : ''}
              ${!canPlaceAtPosition('left') && selectedDomino ? 'border-red-400 opacity-50 cursor-not-allowed' : ''}
            `}
            onMouseEnter={() => setHoveredPosition('left')}
            onMouseLeave={() => setHoveredPosition(null)}
            onClick={() => handlePositionClick('left')}
          >
            <span className="text-white text-2xl">
              {canPlaceAtPosition('left') && selectedDomino ? '✓' : '←'}
            </span>
          </div>
        )}

        {/* Board dominoes */}
        <div className="flex items-center gap-2 flex-wrap justify-center max-w-4xl">
          {boardLayout.map((domino, index) => (
            <div
              key={`board-${domino.id || index}`}
              className="relative"
              style={{
                animation: `slideIn 0.5s ease-out ${index * 0.1}s both`
              }}
            >
              <DominoTile
                domino={domino}
                isHorizontal={domino.isHorizontal}
                isPlayable={false}
                size="normal"
              />
              
              {/* Position indicator */}
              <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-white text-xs opacity-50">
                {index === 0 ? 'البداية' : index === board.length - 1 ? 'النهاية' : ''}
              </div>
            </div>
          ))}
        </div>

        {/* Right placement area */}
        {board.length > 0 && (
          <div
            className={`
              w-16 h-32 border-2 border-dashed border-white/30 rounded-lg
              flex items-center justify-center cursor-pointer
              transition-all duration-200 ml-4
              ${hoveredPosition === 'right' ? 'border-blue-400 bg-blue-400/20' : ''}
              ${canPlaceAtPosition('right') && selectedDomino ? 'border-green-400 hover:bg-green-400/20' : ''}
              ${!canPlaceAtPosition('right') && selectedDomino ? 'border-red-400 opacity-50 cursor-not-allowed' : ''}
            `}
            onMouseEnter={() => setHoveredPosition('right')}
            onMouseLeave={() => setHoveredPosition(null)}
            onClick={() => handlePositionClick('right')}
          >
            <span className="text-white text-2xl">
              {canPlaceAtPosition('right') && selectedDomino ? '✓' : '→'}
            </span>
          </div>
        )}
      </div>

      {/* Board info */}
      <div className="text-center mt-6 text-white">
        <p className="text-sm opacity-75">
          عدد القطع على اللوحة: {board.length}
        </p>
        {board.length > 0 && (
          <p className="text-xs opacity-50 mt-1">
            الطرف الأيسر: {board[0]?.left} | الطرف الأيمن: {board[board.length - 1]?.right}
          </p>
        )}
      </div>

      {/* Instructions */}
      {selectedDomino && isCurrentPlayer && (
        <div className="text-center mt-4">
          <div className="bg-blue-500/20 border border-blue-400/30 rounded-lg p-3 text-white">
            <p className="text-sm">
              قطعة محددة: {selectedDomino.left}-{selectedDomino.right}
            </p>
            <p className="text-xs opacity-75 mt-1">
              اختر الموضع المناسب لوضع القطعة
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default GameBoard;

import React, { useState } from 'react';
import { Volume2, VolumeX, Settings } from 'lucide-react';

const AudioControls = ({ 
  isMuted, 
  volume, 
  onToggleMute, 
  onVolumeChange,
  sounds 
}) => {
  const [showSettings, setShowSettings] = useState(false);

  const handleVolumeChange = (e) => {
    const newVolume = parseFloat(e.target.value);
    onVolumeChange(newVolume);
  };

  const testSound = () => {
    if (sounds) {
      sounds.click();
    }
  };

  return (
    <div className="audio-controls">
      {/* Mute/Unmute Button */}
      <button
        className={`audio-btn ${isMuted ? '' : 'active'}`}
        onClick={onToggleMute}
        title={isMuted ? 'تشغيل الصوت' : 'كتم الصوت'}
      >
        {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
      </button>

      {/* Settings Button */}
      <button
        className={`audio-btn ${showSettings ? 'active' : ''}`}
        onClick={() => setShowSettings(!showSettings)}
        title="إعدادات الصوت"
      >
        <Settings size={20} />
      </button>

      {/* Settings Panel */}
      {showSettings && (
        <div className="absolute top-16 left-0 bg-white/10 backdrop-blur-lg rounded-lg p-4 min-w-[250px] border border-white/20">
          <h3 className="text-white font-bold mb-3">إعدادات الصوت</h3>
          
          {/* Volume Control */}
          <div className="mb-4">
            <label className="text-white text-sm block mb-2">
              مستوى الصوت: {Math.round(volume * 100)}%
            </label>
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={volume}
              onChange={handleVolumeChange}
              className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #4f46e5 0%, #4f46e5 ${volume * 100}%, rgba(255,255,255,0.2) ${volume * 100}%, rgba(255,255,255,0.2) 100%)`
              }}
            />
          </div>

          {/* Sound Test Buttons */}
          <div className="space-y-2">
            <p className="text-white text-sm mb-2">اختبار الأصوات:</p>
            
            <div className="grid grid-cols-2 gap-2">
              <button
                className="btn btn-secondary text-xs py-1 px-2"
                onClick={() => sounds?.placeTile()}
                disabled={isMuted}
              >
                وضع قطعة
              </button>
              
              <button
                className="btn btn-secondary text-xs py-1 px-2"
                onClick={() => sounds?.yourTurn()}
                disabled={isMuted}
              >
                دورك
              </button>
              
              <button
                className="btn btn-secondary text-xs py-1 px-2"
                onClick={() => sounds?.gameStart()}
                disabled={isMuted}
              >
                بداية اللعبة
              </button>
              
              <button
                className="btn btn-secondary text-xs py-1 px-2"
                onClick={() => sounds?.gameWin()}
                disabled={isMuted}
              >
                فوز
              </button>
            </div>
          </div>

          {/* Sound Effects List */}
          <div className="mt-4 pt-3 border-t border-white/20">
            <p className="text-white text-xs opacity-75 mb-2">المؤثرات الصوتية:</p>
            <ul className="text-white text-xs space-y-1 opacity-60">
              <li>• أصوات وضع القطع</li>
              <li>• تنبيهات الأدوار</li>
              <li>• أصوات بداية ونهاية اللعبة</li>
              <li>• أصوات انضمام ومغادرة اللاعبين</li>
              <li>• أصوات الرسائل والأخطاء</li>
            </ul>
          </div>

          {/* Close Button */}
          <button
            className="btn btn-primary text-xs w-full mt-3"
            onClick={() => setShowSettings(false)}
          >
            إغلاق
          </button>
        </div>
      )}
    </div>
  );
};

export default AudioControls;

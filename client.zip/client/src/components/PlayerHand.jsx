import React, { useState } from 'react';
import DominoTile from './DominoTile';

const PlayerHand = ({ 
  dominoes, 
  onDominoSelect, 
  selectedDomino, 
  isCurrentPlayer,
  gameStarted 
}) => {
  const [hoveredDomino, setHoveredDomino] = useState(null);

  const handleDominoClick = (domino) => {
    if (!isCurrentPlayer || !gameStarted) return;
    onDominoSelect(domino);
  };

  if (!dominoes || dominoes.length === 0) {
    return (
      <div className="player-hand">
        <div className="text-white text-center py-8">
          {gameStarted ? 'لا توجد قطع دومينو' : 'في انتظار بدء اللعبة...'}
        </div>
      </div>
    );
  }

  return (
    <div className="player-hand">
      <div className="text-white text-center mb-4">
        <h3 className="text-lg font-bold">
          {isCurrentPlayer ? '🎯 دورك الآن' : 'قطع الدومينو الخاصة بك'}
        </h3>
        <p className="text-sm opacity-75">
          عدد القطع: {dominoes.length}
        </p>
      </div>
      
      <div className="flex flex-wrap justify-center gap-3">
        {dominoes.map((domino, index) => (
          <div
            key={domino.id || `${domino.left}-${domino.right}-${index}`}
            className="relative"
            onMouseEnter={() => setHoveredDomino(domino.id)}
            onMouseLeave={() => setHoveredDomino(null)}
          >
            <DominoTile
              domino={domino}
              isSelected={selectedDomino?.id === domino.id}
              onClick={() => handleDominoClick(domino)}
              isPlayable={isCurrentPlayer && gameStarted}
              size="normal"
            />
            
            {/* Hover tooltip */}
            {hoveredDomino === domino.id && (
              <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded whitespace-nowrap z-10">
                {domino.left === domino.right ? `دبل ${domino.left}` : `${domino.left}-${domino.right}`}
              </div>
            )}
            
            {/* Selection indicator */}
            {selectedDomino?.id === domino.id && (
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                ✓
              </div>
            )}
          </div>
        ))}
      </div>
      
      {/* Instructions */}
      {isCurrentPlayer && gameStarted && (
        <div className="text-center mt-4">
          <p className="text-white text-sm opacity-75">
            {selectedDomino 
              ? 'اختر موضع وضع القطعة على اللوحة' 
              : 'اختر قطعة دومينو للعب'
            }
          </p>
        </div>
      )}
      
      {/* Not your turn indicator */}
      {!isCurrentPlayer && gameStarted && (
        <div className="text-center mt-4">
          <p className="text-yellow-300 text-sm">
            ⏳ انتظر دورك
          </p>
        </div>
      )}
    </div>
  );
};

export default PlayerHand;

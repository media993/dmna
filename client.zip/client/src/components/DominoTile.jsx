import React from 'react';

const DominoTile = ({ 
  domino, 
  isHorizontal = false, 
  isSelected = false, 
  onClick, 
  isPlayable = true,
  size = 'normal' 
}) => {
  const renderDots = (value) => {
    const dots = [];
    const positions = {
      0: [],
      1: [[50, 50]],
      2: [[25, 25], [75, 75]],
      3: [[25, 25], [50, 50], [75, 75]],
      4: [[25, 25], [75, 25], [25, 75], [75, 75]],
      5: [[25, 25], [75, 25], [50, 50], [25, 75], [75, 75]],
      6: [[25, 25], [75, 25], [25, 50], [75, 50], [25, 75], [75, 75]]
    };

    positions[value].forEach((pos, index) => {
      dots.push(
        <div
          key={index}
          className="domino-dot"
          style={{
            position: 'absolute',
            left: `${pos[0]}%`,
            top: `${pos[1]}%`,
            transform: 'translate(-50%, -50%)'
          }}
        />
      );
    });

    return dots;
  };

  const sizeClasses = {
    small: isHorizontal ? 'w-16 h-8' : 'w-8 h-16',
    normal: isHorizontal ? 'w-24 h-12' : 'w-12 h-24',
    large: isHorizontal ? 'w-32 h-16' : 'w-16 h-32'
  };

  return (
    <div
      className={`
        domino-tile 
        ${isHorizontal ? 'horizontal' : ''} 
        ${isSelected ? 'selected' : ''} 
        ${!isPlayable ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
        ${sizeClasses[size]}
        relative
      `}
      onClick={isPlayable ? onClick : undefined}
      style={{
        background: isSelected 
          ? 'linear-gradient(145deg, #e0e7ff, #c7d2fe)' 
          : 'linear-gradient(145deg, #ffffff, #e6e6e6)',
        border: isSelected ? '2px solid #4f46e5' : '2px solid #333',
        boxShadow: isSelected 
          ? '0 0 20px rgba(79, 70, 229, 0.5)' 
          : '0 4px 8px rgba(0, 0, 0, 0.2)'
      }}
    >
      {/* Divider line */}
      <div 
        className={`
          absolute bg-gray-800 
          ${isHorizontal ? 'w-px h-full left-1/2 transform -translate-x-1/2' : 'h-px w-full top-1/2 transform -translate-y-1/2'}
        `}
      />
      
      {/* Left/Top half */}
      <div className={`domino-half ${isHorizontal ? 'w-1/2 h-full' : 'w-full h-1/2'} relative`}>
        {renderDots(domino.left)}
      </div>
      
      {/* Right/Bottom half */}
      <div className={`domino-half ${isHorizontal ? 'w-1/2 h-full' : 'w-full h-1/2'} relative`}>
        {renderDots(domino.right)}
      </div>
      
      {/* Hover effect */}
      {isPlayable && (
        <div className="absolute inset-0 bg-blue-500 opacity-0 hover:opacity-10 transition-opacity duration-200 rounded-lg" />
      )}
    </div>
  );
};

export default DominoTile;

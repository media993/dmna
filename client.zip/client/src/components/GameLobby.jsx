import React, { useState, useEffect } from 'react';
import { Users, Play, RefreshCw, MessageCircle } from 'lucide-react';

const GameLobby = ({
  onCreateRoom,
  onJoinRoom,
  availableRooms,
  onGetRooms,
  isConnected
}) => {
  // Generate random player name
  const generateRandomName = () => {
    const adjectives = ['سريع', 'ذكي', 'قوي', 'ماهر', 'بطل', 'نجم', 'أسطورة', 'محترف'];
    const nouns = ['اللاعب', 'البطل', 'النجم', 'الماهر', 'القائد', 'الخبير', 'المحارب', 'الأسطورة'];
    const randomAdj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const randomNoun = nouns[Math.floor(Math.random() * nouns.length)];
    const randomNum = Math.floor(Math.random() * 999) + 1;
    return `${randomAdj} ${randomNoun} ${randomNum}`;
  };

  const [playerName, setPlayerName] = useState(generateRandomName());
  const [roomIdToJoin, setRoomIdToJoin] = useState('');
  const [showJoinForm, setShowJoinForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Get rooms list on component mount
    if (isConnected) {
      onGetRooms();
    }
  }, [isConnected, onGetRooms]);

  const handleCreateRoom = async (e) => {
    e.preventDefault();
    if (!playerName.trim()) return;
    
    setIsLoading(true);
    try {
      await onCreateRoom(playerName.trim());
    } finally {
      setIsLoading(false);
    }
  };

  const handleJoinRoom = async (e) => {
    e.preventDefault();
    if (!playerName.trim() || !roomIdToJoin.trim()) return;
    
    setIsLoading(true);
    try {
      await onJoinRoom(roomIdToJoin.trim().toUpperCase(), playerName.trim());
    } finally {
      setIsLoading(false);
    }
  };

  const handleJoinExistingRoom = async (roomId) => {
    if (!playerName.trim()) {
      alert('يرجى إدخال اسمك أولاً');
      return;
    }
    
    setIsLoading(true);
    try {
      await onJoinRoom(roomId, playerName.trim());
    } finally {
      setIsLoading(false);
    }
  };

  const refreshRooms = () => {
    onGetRooms();
  };

  return (
    <div className="lobby-container fade-in">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">🎲 لعبة الدومينو</h1>
        <p className="text-white/80 text-lg mb-2">العب مع أصدقائك أونلاين</p>
        <p className="text-white/60 text-sm mb-4">
          🎮 دخول مباشر - لا حاجة لتسجيل دخول!
        </p>
        <div className="flex items-center justify-center gap-2">
          <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-400' : 'bg-red-400'}`}></div>
          <span className="text-white text-sm">
            {isConnected ? '✅ متصل بالخادم' : '❌ غير متصل'}
          </span>
        </div>
        {!isConnected && (
          <p className="text-red-400 text-xs mt-2">
            يرجى التحقق من اتصال الإنترنت...
          </p>
        )}
      </div>

      {/* Player Name Input */}
      <div className="mb-8">
        <label className="block text-white text-sm font-medium mb-2">
          اسم اللاعب
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            placeholder="أدخل اسمك"
            className="input flex-1"
            maxLength={20}
            disabled={isLoading}
          />
          <button
            type="button"
            onClick={() => setPlayerName(generateRandomName())}
            className="btn btn-secondary px-3 text-sm"
            disabled={isLoading}
            title="توليد اسم عشوائي"
          >
            🎲
          </button>
        </div>
        <p className="text-white/60 text-xs mt-1">
          💡 يمكنك تعديل الاسم أو الضغط على 🎲 لتوليد اسم جديد
        </p>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <button
          onClick={handleCreateRoom}
          disabled={!playerName.trim() || isLoading || !isConnected}
          className="btn btn-primary flex items-center justify-center gap-2 py-4 text-lg"
        >
          <Users size={24} />
          <div className="text-left">
            <div>🎯 إنشاء غرفة جديدة</div>
            <div className="text-xs opacity-75">ابدأ لعبة جديدة</div>
          </div>
        </button>

        <button
          onClick={() => setShowJoinForm(!showJoinForm)}
          disabled={!playerName.trim() || isLoading}
          className="btn btn-secondary flex items-center justify-center gap-2 py-4 text-lg"
        >
          <MessageCircle size={24} />
          <div className="text-left">
            <div>🔗 انضمام بالكود</div>
            <div className="text-xs opacity-75">لديك كود غرفة؟</div>
          </div>
        </button>
      </div>

      {/* Join Room Form */}
      {showJoinForm && (
        <div className="bg-white/10 rounded-lg p-4 mb-8 slide-in">
          <form onSubmit={handleJoinRoom} className="space-y-4">
            <div>
              <label className="block text-white text-sm font-medium mb-2">
                كود الغرفة
              </label>
              <input
                type="text"
                value={roomIdToJoin}
                onChange={(e) => setRoomIdToJoin(e.target.value.toUpperCase())}
                placeholder="أدخل كود الغرفة"
                className="input w-full"
                maxLength={8}
                disabled={isLoading}
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                disabled={!roomIdToJoin.trim() || isLoading}
                className="btn btn-primary flex-1"
              >
                انضمام
              </button>
              <button
                type="button"
                onClick={() => setShowJoinForm(false)}
                className="btn btn-secondary"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Available Rooms */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white">الغرف المتاحة</h2>
          <button
            onClick={refreshRooms}
            disabled={isLoading || !isConnected}
            className="btn btn-secondary flex items-center gap-2 text-sm py-2 px-3"
          >
            <RefreshCw size={16} />
            تحديث
          </button>
        </div>

        {availableRooms.length === 0 ? (
          <div className="text-center py-8 text-white/60">
            <Users size={48} className="mx-auto mb-4 opacity-50" />
            <p>لا توجد غرف متاحة حالياً</p>
            <p className="text-sm mt-2">كن أول من ينشئ غرفة!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {availableRooms.map((room) => (
              <div key={room.roomId} className="room-card">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-white">غرفة {room.roomId}</h3>
                    <p className="text-sm text-white/70">
                      اللاعبون: {room.playerCount}/4
                    </p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {room.players.map((player, index) => (
                        <span
                          key={index}
                          className="text-xs bg-white/20 px-2 py-1 rounded text-white"
                        >
                          {player}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${
                        room.gameStarted ? 'bg-red-400' : 'bg-green-400'
                      }`}></span>
                      <span className="text-xs text-white/70">
                        {room.gameStarted ? 'جارية' : 'في الانتظار'}
                      </span>
                    </div>
                    <button
                      onClick={() => handleJoinExistingRoom(room.roomId)}
                      disabled={
                        room.playerCount >= 4 || 
                        room.gameStarted || 
                        isLoading || 
                        !playerName.trim()
                      }
                      className="btn btn-primary text-sm py-1 px-3"
                    >
                      {room.playerCount >= 4 ? 'ممتلئة' : 'انضمام'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Start Guide */}
      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-lg p-4 mb-4">
        <h3 className="text-lg font-bold text-white mb-3">🚀 ابدأ اللعب الآن!</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div className="text-center">
            <div className="text-2xl mb-2">1️⃣</div>
            <p className="text-white/80">اختر اسمك أو استخدم الاسم المقترح</p>
          </div>
          <div className="text-center">
            <div className="text-2xl mb-2">2️⃣</div>
            <p className="text-white/80">أنشئ غرفة جديدة أو انضم لغرفة موجودة</p>
          </div>
          <div className="text-center">
            <div className="text-2xl mb-2">3️⃣</div>
            <p className="text-white/80">انتظر 4 لاعبين وابدأ اللعب!</p>
          </div>
        </div>
      </div>

      {/* Game Rules */}
      <div className="bg-white/5 rounded-lg p-4">
        <h3 className="text-lg font-bold text-white mb-3">📋 قواعد اللعبة</h3>
        <ul className="text-white/80 text-sm space-y-2">
          <li>🎯 يلعب 4 أشخاص في كل غرفة</li>
          <li>🎲 كل لاعب يحصل على 7 قطع دومينو</li>
          <li>⭐ يبدأ اللاعب الذي لديه أعلى دبل</li>
          <li>🏆 الهدف هو التخلص من جميع القطع أولاً</li>
          <li>🔗 يجب أن تتطابق الأرقام عند وضع القطع</li>
          <li>💬 استخدم المحادثة للتواصل مع اللاعبين</li>
        </ul>
      </div>

      {isLoading && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white/10 backdrop-blur-lg rounded-lg p-6 text-center">
            <div className="spinner mx-auto mb-4"></div>
            <p className="text-white">جاري المعالجة...</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default GameLobby;

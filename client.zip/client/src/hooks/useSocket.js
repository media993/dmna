import { useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import toast from 'react-hot-toast';

const useSocket = () => {
  const socketRef = useRef(null);
  const [isConnected, setIsConnected] = useState(false);
  const [gameState, setGameState] = useState(null);
  const [playerHand, setPlayerHand] = useState([]);
  const [roomId, setRoomId] = useState(null);
  const [availableRooms, setAvailableRooms] = useState([]);
  const [chatMessages, setChatMessages] = useState([]);

  useEffect(() => {
    // Initialize socket connection
    // Auto-detect server URL based on environment
    const serverUrl = window.location.hostname === 'localhost'
      ? 'http://localhost:8080'
      : 'https://domino-game-server-production.up.railway.app'; // Replace with your Railway URL

    console.log('🔌 Connecting to server:', serverUrl);
    console.log('🌐 Environment:', window.location.hostname === 'localhost' ? 'Development' : 'Production');

    socketRef.current = io(serverUrl, {
      transports: ['websocket', 'polling'],
      withCredentials: true,
      autoConnect: true,
      forceNew: true
    });

    const socket = socketRef.current;

    // Connection events
    socket.on('connect', () => {
      console.log('✅ Connected to server:', socket.id);
      setIsConnected(true);
      toast.success('متصل بالخادم');
    });

    socket.on('disconnect', (reason) => {
      console.log('❌ Disconnected from server:', reason);
      setIsConnected(false);
      toast.error('انقطع الاتصال بالخادم');
    });

    socket.on('connect_error', (error) => {
      console.error('🔥 Connection error:', error);
      toast.error('خطأ في الاتصال بالخادم');
    });

    // Room events
    socket.on('roomJoined', (data) => {
      setGameState(data.game);
      setPlayerHand(data.playerHand);
      setRoomId(data.roomId);
      toast.success(`انضممت للغرفة: ${data.roomId}`);
    });

    socket.on('playerJoined', (data) => {
      setGameState(data.game);
      toast.success(`انضم لاعب جديد: ${data.newPlayer.name}`);
    });

    socket.on('playerLeft', (data) => {
      setGameState(data.game);
      toast.info('غادر أحد اللاعبين');
    });

    socket.on('playerStatusChanged', (data) => {
      setGameState(data.game);
    });

    // Game events
    socket.on('gameStarted', (data) => {
      setGameState(data.game);
      setPlayerHand(data.playerHand);
      toast.success('بدأت اللعبة!');
    });

    socket.on('gameUpdated', (data) => {
      setGameState(data.game);
      setPlayerHand(data.playerHand);
    });

    socket.on('gameEnded', (data) => {
      setGameState(data.game);
      toast.success(`انتهت اللعبة! الفائز: ${data.winner.name}`);
    });

    // Room list
    socket.on('roomsList', (rooms) => {
      setAvailableRooms(rooms);
    });

    // Chat
    socket.on('chatMessage', (data) => {
      setChatMessages(prev => [...prev, data]);
    });

    // Error handling
    socket.on('error', (error) => {
      toast.error(error.message || 'حدث خطأ');
    });

    // Cleanup
    return () => {
      socket.disconnect();
    };
  }, []);

  // Socket methods
  const createRoom = (playerName) => {
    if (socketRef.current) {
      socketRef.current.emit('createRoom', { playerName });
    }
  };

  const joinRoom = (roomId, playerName) => {
    if (socketRef.current) {
      socketRef.current.emit('joinRoom', { roomId, playerName });
    }
  };

  const startGame = () => {
    if (socketRef.current) {
      socketRef.current.emit('startGame');
    }
  };

  const playDomino = (dominoId, position) => {
    if (socketRef.current) {
      socketRef.current.emit('playDomino', { dominoId, position });
    }
  };

  const setPlayerReady = (ready) => {
    if (socketRef.current) {
      socketRef.current.emit('playerReady', { ready });
    }
  };

  const getRooms = () => {
    if (socketRef.current) {
      socketRef.current.emit('getRooms');
    }
  };

  const sendChatMessage = (message) => {
    if (socketRef.current) {
      socketRef.current.emit('chatMessage', { message });
    }
  };

  const leaveRoom = () => {
    setGameState(null);
    setPlayerHand([]);
    setRoomId(null);
    setChatMessages([]);
  };

  return {
    isConnected,
    gameState,
    playerHand,
    roomId,
    availableRooms,
    chatMessages,
    createRoom,
    joinRoom,
    startGame,
    playDomino,
    setPlayerReady,
    getRooms,
    sendChatMessage,
    leaveRoom
  };
};

export default useSocket;
